num1 = 14
num2 = 5
print(num1//num2)